-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 12, 2025 at 03:19 AM
-- Server version: 10.6.21-MariaDB
-- PHP Version: 8.3.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shribala_tracker`
--

-- --------------------------------------------------------

--
-- Table structure for table `lending`
--

CREATE TABLE `lending` (
  `id` int(11) UNSIGNED NOT NULL,
  `UserId` int(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `date_of_lending` date NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` varchar(250) DEFAULT NULL,
  `status` enum('pending','received') NOT NULL,
  `current_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lending`
--

INSERT INTO `lending` (`id`, `UserId`, `name`, `date_of_lending`, `amount`, `description`, `status`, `current_time`) VALUES
(10, 26, 'admin', '2023-03-16', 5000.00, 'hiii', 'pending', '2023-04-04 13:31:19'),
(11, 30, 'shivmodi', '2023-03-31', 6000.00, 'llll', 'received', '2023-04-04 14:28:52'),
(12, 26, 'king', '2023-03-22', 6000.00, 'hii bro give me my money 💵💵', 'pending', '2023-04-07 05:04:21'),
(13, 31, 'Shiv Modi', '2023-04-05', 5000.00, 'friend ', 'pending', '2023-04-05 14:13:15'),
(14, 31, 'Krsih Patel', '2023-04-04', 2000.00, 'Friends', 'received', '2023-04-05 14:13:48'),
(15, 66, 'shivmodi', '2023-04-03', 1000.00, 'I want to take money from harsh', 'received', '2023-04-11 13:26:38'),
(16, 67, 'Shiv Modi', '2023-04-05', 500.00, 'I want to take money from harsh', 'received', '2023-04-11 13:42:16'),
(17, 68, 'krish patel', '2023-04-04', 500.00, 'i want to take from krish patel on 14/04/23', 'received', '2023-04-12 05:23:44'),
(19, 68, 'shiv modi', '2023-04-12', 5000.00, 'i want to take money from shiv ', 'pending', '2023-04-12 05:28:56'),
(21, 73, 'Manish Kumar', '2025-04-11', 500.00, 'gdfs', 'received', '2025-04-11 11:42:30');

-- --------------------------------------------------------

--
-- Table structure for table `tblcategory`
--

CREATE TABLE `tblcategory` (
  `CategoryId` int(11) NOT NULL,
  `CategoryName` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `UserId` int(11) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tblcategory`
--

INSERT INTO `tblcategory` (`CategoryId`, `CategoryName`, `UserId`, `CreatedAt`) VALUES
(73, 'Food ', 73, '2023-04-12 05:06:22'),
(74, 'Games 🎮', 73, '2023-04-12 05:06:30'),
(76, 'Petrol ⛽⛽', 73, '2023-04-12 05:11:53'),
(77, 'Electricity ⚡⚡', 73, '2023-04-12 05:13:04'),
(78, 'Rent 🏠', 73, '2023-04-12 05:14:10'),
(79, 'Entertainment', 73, '2023-04-12 10:27:52'),
(80, 'Hostel fees', 73, '2025-04-11 11:40:16'),
(81, 'Food ', 73, '2025-04-11 12:22:35');

-- --------------------------------------------------------

--
-- Table structure for table `tblexpense`
--

CREATE TABLE `tblexpense` (
  `ID` int(10) NOT NULL,
  `UserId` int(10) NOT NULL,
  `ExpenseDate` date DEFAULT NULL,
  `CategoryId` int(11) NOT NULL,
  `category` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ExpenseCost` varchar(200) DEFAULT NULL,
  `Description` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `NoteDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblexpense`
--

INSERT INTO `tblexpense` (`ID`, `UserId`, `ExpenseDate`, `CategoryId`, `category`, `ExpenseCost`, `Description`, `NoteDate`) VALUES
(116, 73, '2025-04-02', 57, 'Grass', '5000', 'dd ', '2025-04-11 14:06:11'),
(117, 73, '2025-04-02', 59, 'Games', '5000', 'hiiiii ', '2025-04-11 14:06:11'),
(122, 73, '2025-04-02', 60, 'Food ', '2000', '😋😋 ', '2025-04-11 14:06:11'),
(123, 73, '2025-04-02', 61, 'Food 😋😋', '5000', '🌽🌽🌽 ', '2025-04-11 14:06:11'),
(124, 73, '2025-04-02', 65, 'Games 🎮', '5000', 'PS5 🎮🎮🎮 ', '2025-04-11 14:06:11'),
(126, 73, '2025-04-04', 64, 'Entertainment 🎞️', '10000', 'movie 🍿🍿 ', '2025-04-11 14:06:11'),
(127, 73, '2025-04-03', 66, 'Tea ☕', '15000', 'tea month cost ', '2025-04-11 14:06:11'),
(128, 73, '2025-04-02', 67, 'Bank 🏦🏦', '60000', 'bank money deposit ', '2025-04-11 14:06:11'),
(130, 73, '2025-04-10', 69, 'Food', '500', 'vegetables 🍅🍅 ', '2025-04-11 14:06:11'),
(131, 73, '2025-04-11', 70, 'Games 🎮', '1000', 'PS5 ', '2025-04-11 14:06:11'),
(132, 73, '2025-04-11', 71, 'Food', '600', 'Vegetables 🍅🍅 ', '2025-04-11 14:06:11'),
(133, 73, '2025-04-11', 72, 'Games 🎮', '5000', 'Ps5 ', '2025-04-11 14:06:11'),
(136, 73, '2025-04-08', 74, 'Games 🎮', '980', 'PS5  🎞️🎞️ ', '2025-04-11 14:06:11'),
(137, 73, '2025-04-10', 76, 'Petrol ⛽⛽', '500', 'petrol  ', '2025-04-11 14:06:11'),
(138, 68, '2025-04-11', 77, 'Electricity ⚡⚡', '2523', 'electricity billl 🔴 ', '2025-04-11 14:06:11'),
(139, 68, '2025-04-10', 78, 'Rent 🏠', '15000', 'rent  ', '2025-04-11 14:06:11'),
(141, 68, '2025-04-10', 75, 'Entertainment 🍿', '8000', 'movie ', '2025-04-11 14:06:11'),
(147, 73, '2025-04-11', 80, 'Hostel fees', '5999', 'Hostel Fees ', '2025-04-11 14:06:11'),
(148, 73, '2025-04-11', 73, 'Food ', '508', 'Cubic ', '2025-04-11 12:15:59'),
(149, 73, '2025-04-11', 74, 'Games 🎮', '500', 'Bowling ', '2025-04-11 12:22:50'),
(150, 73, '2025-04-11', 77, 'Electricity ⚡⚡', '10000', 'ok ', '2025-04-11 12:48:42'),
(151, 73, '2025-04-11', 77, 'Electricity ⚡⚡', '600', 'okok ', '2025-04-11 12:50:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `verification_code` varchar(12) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `verification_code`, `created_at`) VALUES
(68, 'User', 'user@gmail.com', '9245657856', '$2y$10$JkvQ00olAxMBVQBUJ6kZp.rNtv0v5K7OChUeVvR04uAq8ZEFWDC2.', '4ebebb3c3d07', '2023-04-12 10:31:16'),
(73, 'Ayushi', 'ayushi@gmail.com', '9888696850', '$2y$10$HHgSabeHA4bXHniLvu/sfuz.XzOSvyQMwv5dUZuxR3xI6rHScxQnu', 'dc1d5d4d58ed', '2025-04-11 11:36:11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lending`
--
ALTER TABLE `lending`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD PRIMARY KEY (`CategoryId`),
  ADD KEY `UserId` (`UserId`);

--
-- Indexes for table `tblexpense`
--
ALTER TABLE `tblexpense`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lending`
--
ALTER TABLE `lending`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tblcategory`
--
ALTER TABLE `tblcategory`
  MODIFY `CategoryId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `tblexpense`
--
ALTER TABLE `tblexpense`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=152;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblcategory`
--
ALTER TABLE `tblcategory`
  ADD CONSTRAINT `tblcategory_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
